# Contenido de la semana 5 - Webscrapping y API's

- Webscrapping, Requests y Beautiful Soup 4
- API's
- Scrapy y filtrado de datos

