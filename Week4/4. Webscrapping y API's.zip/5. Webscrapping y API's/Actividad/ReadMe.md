# Contenido de la semana 1 - Introducción a Python

1. Introducción a la suite de Anaconda
2. Introducción al uso de Jupyter notebooks 
3. Introducción al lenguaje Python 
4. Ejercicios a realizar en Python
